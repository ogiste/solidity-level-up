export class IpfsDataDto {
  constructor(public path: string, public cid: object, public size: number) {}
}
