export function setContracts({ commit }, contracts) {
  commit('setContracts', contracts);
}
