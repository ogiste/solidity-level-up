export const environment = {
  network: 'ropsten',
  tokenContractAddress: '0x03d25a324b3c56f3520ce74df120D6b984522A99',
  apiAddress: 'http://127.0.0.1:3000/',
  production: true
};
