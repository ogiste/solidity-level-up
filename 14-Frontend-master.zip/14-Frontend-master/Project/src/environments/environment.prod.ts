export const environment = {
  network: 'ropsten',
  tokenContractAddress: '0x03d25a324b3c56f3520ce74df120D6b984522A99',
  production: true
};
